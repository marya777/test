<?php
class SchMountain extends SchLandform{
	function __construct(){$this->namespace = "Mountain";}
}