<?php
class SchFlorist extends SchStore{
	function __construct(){$this->namespace = "Florist";}
}