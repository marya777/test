<?php
class SchCemetery extends SchCivicStructure{
	function __construct(){$this->namespace = "Cemetery";}
}