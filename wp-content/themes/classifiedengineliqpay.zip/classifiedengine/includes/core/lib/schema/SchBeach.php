<?php
class SchBeach extends SchCivicStructure{
	function __construct(){$this->namespace = "Beach";}
}