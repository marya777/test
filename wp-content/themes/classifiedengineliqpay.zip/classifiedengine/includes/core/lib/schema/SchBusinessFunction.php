<?php
class SchBusinessFunction extends SchEnumeration{
	function __construct(){$this->namespace = "BusinessFunction";}
}