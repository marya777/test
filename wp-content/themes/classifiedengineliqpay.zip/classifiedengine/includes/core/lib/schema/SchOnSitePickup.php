<?php
class SchOnSitePickup extends SchDeliveryMethod{
	function __construct(){$this->namespace = "OnSitePickup";}
}