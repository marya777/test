<?php
class SchBloodTest extends SchMedicalTest{
	function __construct(){$this->namespace = "BloodTest";}
}