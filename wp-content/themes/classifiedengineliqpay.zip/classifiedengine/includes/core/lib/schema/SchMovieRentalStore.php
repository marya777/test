<?php
class SchMovieRentalStore extends SchStore{
	function __construct(){$this->namespace = "MovieRentalStore";}
}