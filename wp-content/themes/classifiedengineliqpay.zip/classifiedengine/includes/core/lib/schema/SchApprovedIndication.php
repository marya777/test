<?php
class SchApprovedIndication extends SchMedicalIndication{
	function __construct(){$this->namespace = "ApprovedIndication";}
}