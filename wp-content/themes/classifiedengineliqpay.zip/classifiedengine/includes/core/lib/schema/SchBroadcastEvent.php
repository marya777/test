<?php
class SchBroadcastEvent extends SchPublicationEvent{
	function __construct(){$this->namespace = "BroadcastEvent";}
}