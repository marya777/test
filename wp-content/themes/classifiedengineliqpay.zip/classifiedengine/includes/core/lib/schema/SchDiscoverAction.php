<?php
class SchDiscoverAction extends SchFindAction{
	function __construct(){$this->namespace = "DiscoverAction";}
}