<?php
class SchBefriendAction extends SchInteractAction{
	function __construct(){$this->namespace = "BefriendAction";}
}