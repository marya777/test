<?php
class SchCafeOrCoffeeShop extends SchFoodEstablishment{
	function __construct(){$this->namespace = "CafeOrCoffeeShop";}
}