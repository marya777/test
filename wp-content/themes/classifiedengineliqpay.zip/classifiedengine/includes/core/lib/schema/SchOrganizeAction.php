<?php
class SchOrganizeAction extends SchAction{
	function __construct(){$this->namespace = "OrganizeAction";}
}