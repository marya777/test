<?php
class SchHealthClub extends SchSportsActivityLocation{
	function __construct(){$this->namespace = "HealthClub";}
}