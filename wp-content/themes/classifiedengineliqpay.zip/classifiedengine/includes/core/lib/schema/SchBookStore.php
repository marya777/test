<?php
class SchBookStore extends SchStore{
	function __construct(){$this->namespace = "BookStore";}
}