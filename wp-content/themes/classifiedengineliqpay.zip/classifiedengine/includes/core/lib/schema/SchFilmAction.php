<?php
class SchFilmAction extends SchCreateAction{
	function __construct(){$this->namespace = "FilmAction";}
}