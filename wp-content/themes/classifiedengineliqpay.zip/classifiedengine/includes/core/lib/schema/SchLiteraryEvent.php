<?php
class SchLiteraryEvent extends SchEvent{
	function __construct(){$this->namespace = "LiteraryEvent";}
}