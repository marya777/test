<?php
class SchPhysicalTherapy extends SchMedicalTherapy{
	function __construct(){$this->namespace = "PhysicalTherapy";}
}