<?php
class SchCollegeOrUniversity extends SchEducationalOrganization{
	function __construct(){$this->namespace = "CollegeOrUniversity";}
}