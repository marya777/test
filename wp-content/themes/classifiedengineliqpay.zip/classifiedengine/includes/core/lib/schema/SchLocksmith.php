<?php
class SchLocksmith extends SchProfessionalService{
	function __construct(){$this->namespace = "Locksmith";}
}