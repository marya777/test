<?php
class SchChurch extends SchPlaceOfWorship{
	function __construct(){$this->namespace = "Church";}
}