<?php
class SchAmusementPark extends SchEntertainmentBusiness{
	function __construct(){$this->namespace = "AmusementPark";}
}