<?php
class SchFireStation extends SchEmergencyService{
	function __construct(){$this->namespace = "FireStation";}
}