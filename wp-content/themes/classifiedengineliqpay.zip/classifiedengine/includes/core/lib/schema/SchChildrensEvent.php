<?php
class SchChildrensEvent extends SchEvent{
	function __construct(){$this->namespace = "ChildrensEvent";}
}