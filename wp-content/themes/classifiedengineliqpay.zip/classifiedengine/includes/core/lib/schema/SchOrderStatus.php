<?php
class SchOrderStatus extends SchEnumeration{
	function __construct(){$this->namespace = "OrderStatus";}
}