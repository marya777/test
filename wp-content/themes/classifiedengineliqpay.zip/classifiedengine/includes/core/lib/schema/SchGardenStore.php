<?php
class SchGardenStore extends SchStore{
	function __construct(){$this->namespace = "GardenStore";}
}