<?php
class SchMedicalImagingTechnique extends SchEnumeration{
	function __construct(){$this->namespace = "MedicalImagingTechnique";}
}