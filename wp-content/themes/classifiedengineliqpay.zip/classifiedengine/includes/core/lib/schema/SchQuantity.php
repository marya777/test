<?php
class SchQuantity extends SchIntangible{
	function __construct(){$this->namespace = "Quantity";}
}