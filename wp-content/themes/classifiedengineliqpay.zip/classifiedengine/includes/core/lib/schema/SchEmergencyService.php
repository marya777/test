<?php
class SchEmergencyService extends SchLocalBusiness{
	function __construct(){$this->namespace = "EmergencyService";}
}