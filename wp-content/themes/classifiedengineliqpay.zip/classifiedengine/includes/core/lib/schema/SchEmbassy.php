<?php
class SchEmbassy extends SchGovernmentBuilding{
	function __construct(){$this->namespace = "Embassy";}
}