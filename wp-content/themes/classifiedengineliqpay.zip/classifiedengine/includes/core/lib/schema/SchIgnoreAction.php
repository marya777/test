<?php
class SchIgnoreAction extends SchAssessAction{
	function __construct(){$this->namespace = "IgnoreAction";}
}