<?php
class SchProfessionalService extends SchLocalBusiness{
	function __construct(){$this->namespace = "ProfessionalService";}
}