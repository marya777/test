<?php
class SchElectrician extends SchHomeAndConstructionBusiness{
	function __construct(){$this->namespace = "Electrician";}
}