<?php
class SchNotary extends SchProfessionalService{
	function __construct(){$this->namespace = "Notary";}
}