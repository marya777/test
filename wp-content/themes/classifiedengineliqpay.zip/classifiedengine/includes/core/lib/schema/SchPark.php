<?php
class SchPark extends SchCivicStructure{
	function __construct(){$this->namespace = "Park";}
}