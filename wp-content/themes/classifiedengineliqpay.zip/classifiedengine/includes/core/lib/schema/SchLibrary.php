<?php
class SchLibrary extends SchLocalBusiness{
	function __construct(){$this->namespace = "Library";}
}