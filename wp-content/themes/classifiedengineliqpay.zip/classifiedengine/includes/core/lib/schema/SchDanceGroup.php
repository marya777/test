<?php
class SchDanceGroup extends SchPerformingGroup{
	function __construct(){$this->namespace = "DanceGroup";}
}