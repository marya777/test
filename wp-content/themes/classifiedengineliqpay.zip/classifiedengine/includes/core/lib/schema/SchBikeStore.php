<?php
class SchBikeStore extends SchStore{
	function __construct(){$this->namespace = "BikeStore";}
}