<?php
class SchGovernmentOffice extends SchLocalBusiness{
	function __construct(){$this->namespace = "GovernmentOffice";}
}