<?php
class SchArriveAction extends SchMoveAction{
	function __construct(){$this->namespace = "ArriveAction";}
}