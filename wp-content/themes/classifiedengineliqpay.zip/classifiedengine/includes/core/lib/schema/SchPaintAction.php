<?php
class SchPaintAction extends SchCreateAction{
	function __construct(){$this->namespace = "PaintAction";}
}