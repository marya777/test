<?php
class SchExerciseGym extends SchSportsActivityLocation{
	function __construct(){$this->namespace = "ExerciseGym";}
}