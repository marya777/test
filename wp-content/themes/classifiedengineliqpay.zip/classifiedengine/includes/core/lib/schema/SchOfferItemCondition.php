<?php
class SchOfferItemCondition extends SchEnumeration{
	function __construct(){$this->namespace = "OfferItemCondition";}
}