<?php
class SchAnimalShelter extends SchLocalBusiness{
	function __construct(){$this->namespace = "AnimalShelter";}
}