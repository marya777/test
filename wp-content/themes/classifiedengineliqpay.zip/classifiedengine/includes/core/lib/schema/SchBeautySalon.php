<?php
class SchBeautySalon extends SchHealthAndBeautyBusiness{
	function __construct(){$this->namespace = "BeautySalon";}
}