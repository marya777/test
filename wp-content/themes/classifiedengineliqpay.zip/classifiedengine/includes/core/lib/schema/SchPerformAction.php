<?php
class SchPerformAction extends SchPlayAction{
	protected $entertainmentBusiness	=	'EntertainmentBusiness';
	function __construct(){$this->namespace = "PerformAction";}
}