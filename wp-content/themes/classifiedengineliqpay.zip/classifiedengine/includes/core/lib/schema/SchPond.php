<?php
class SchPond extends SchBodyOfWater{
	function __construct(){$this->namespace = "Pond";}
}