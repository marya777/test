<?php
class SchComputerStore extends SchStore{
	function __construct(){$this->namespace = "ComputerStore";}
}