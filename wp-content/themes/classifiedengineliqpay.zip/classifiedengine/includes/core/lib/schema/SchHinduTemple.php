<?php
class SchHinduTemple extends SchPlaceOfWorship{
	function __construct(){$this->namespace = "HinduTemple";}
}