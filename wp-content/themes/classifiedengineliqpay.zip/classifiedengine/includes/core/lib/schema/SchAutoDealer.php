<?php
class SchAutoDealer extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "AutoDealer";}
}