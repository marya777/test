<?php
class SchCreditCard extends SchPaymentMethod{
	function __construct(){$this->namespace = "CreditCard";}
}