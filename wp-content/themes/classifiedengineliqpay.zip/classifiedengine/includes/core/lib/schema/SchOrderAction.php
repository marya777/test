<?php
class SchOrderAction extends SchTradeAction{
	function __construct(){$this->namespace = "OrderAction";}
}