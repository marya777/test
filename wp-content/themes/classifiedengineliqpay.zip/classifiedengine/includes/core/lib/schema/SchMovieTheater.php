<?php
class SchMovieTheater extends SchEntertainmentBusiness{
	function __construct(){$this->namespace = "MovieTheater";}
}