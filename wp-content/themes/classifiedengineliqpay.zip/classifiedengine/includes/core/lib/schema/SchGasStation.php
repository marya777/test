<?php
class SchGasStation extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "GasStation";}
}