<?php
class SchDentist extends SchMedicalOrganization{
	function __construct(){$this->namespace = "Dentist";}
}