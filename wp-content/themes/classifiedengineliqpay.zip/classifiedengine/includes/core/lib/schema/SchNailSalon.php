<?php
class SchNailSalon extends SchHealthAndBeautyBusiness{
	function __construct(){$this->namespace = "NailSalon";}
}