<?php
class SchCourthouse extends SchGovernmentBuilding{
	function __construct(){$this->namespace = "Courthouse";}
}