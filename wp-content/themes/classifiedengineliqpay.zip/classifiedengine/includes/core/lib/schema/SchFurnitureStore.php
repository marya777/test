<?php
class SchFurnitureStore extends SchStore{
	function __construct(){$this->namespace = "FurnitureStore";}
}