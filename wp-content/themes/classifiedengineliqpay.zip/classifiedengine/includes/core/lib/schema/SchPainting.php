<?php
class SchPainting extends SchCreativeWork{
	function __construct(){$this->namespace = "Painting";}
}