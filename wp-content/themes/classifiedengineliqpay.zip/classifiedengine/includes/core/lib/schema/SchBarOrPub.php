<?php
class SchBarOrPub extends SchFoodEstablishment{
	function __construct(){$this->namespace = "BarOrPub";}
}