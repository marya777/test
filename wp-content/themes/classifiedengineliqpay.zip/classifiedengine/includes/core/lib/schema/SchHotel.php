<?php
class SchHotel extends SchLodgingBusiness{
	function __construct(){$this->namespace = "Hotel";}
}