<?php
class SchAddAction extends SchUpdateAction{
	function __construct(){$this->namespace = "AddAction";}
}