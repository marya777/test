<?php
class SchMedicalGuidelineContraindication extends SchMedicalGuideline{
	function __construct(){$this->namespace = "MedicalGuidelineContraindication";}
}