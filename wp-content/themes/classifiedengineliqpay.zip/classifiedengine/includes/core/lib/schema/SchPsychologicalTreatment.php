<?php
class SchPsychologicalTreatment extends SchMedicalTherapy{
	function __construct(){$this->namespace = "PsychologicalTreatment";}
}