<?php
class SchGolfCourse extends SchSportsActivityLocation{
	function __construct(){$this->namespace = "GolfCourse";}
}